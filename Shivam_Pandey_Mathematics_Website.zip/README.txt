SHIVAM PANDEY — MATHEMATICS LEARNING HUB

Included:
- index.html: responsive website homepage with course categories and search.

Before publishing:
1. Replace YOUR_EMAIL_HERE in index.html with your contact email.
2. Replace the '#' on the Video Lectures link with your YouTube channel URL.
3. Add PDF links to each category. You can upload PDFs to Google Drive, set sharing to
   'Anyone with the link' (only for material you have permission to share), then add
   View/Download links to the relevant card or create category pages.

To publish free:
- Netlify: create a free account, then deploy this folder by dragging it into the
  Netlify Drop page.
- GitHub Pages: upload index.html to a repository and enable Pages in repository settings.

This package is a ready-to-publish starter site; it is not live on the internet yet.
